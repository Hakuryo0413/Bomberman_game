package com.g10.screens;

public enum ScreenType {
    HOME_SCREEN, GAME_SCREEN
}
